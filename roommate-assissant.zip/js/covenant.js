/* ===== Covenant Module ===== */
const Covenant = {
  render() {
    const tpl = document.getElementById('tpl-covenant');
    document.getElementById('page-content').innerHTML = '';
    document.getElementById('page-content').appendChild(tpl.content.cloneNode(true));

    document.getElementById('btn-edit-covenant').addEventListener('click', () => this.showEditModal());

    this.renderCovenant();
    this.renderSignatures();
  },

  renderCovenant() {
    const covenant = DB.getCovenant();
    const container = document.getElementById('covenant-display');

    // Parse and format covenant content with section headers
    const lines = covenant.content.split('\n');
    let html = '';
    lines.forEach(line => {
      if (line.startsWith('第') && line.includes('章')) {
        html += `<h3>${line}</h3>`;
      } else if (line.trim() === '') {
        html += '<br>';
      } else {
        html += `<p>${line}</p>`;
      }
    });
    container.innerHTML = html;
  },

  renderSignatures() {
    const user = Auth.currentUser;
    const members = DB.getHouseholdMembers(user.id);
    const covenant = DB.getCovenant();
    const container = document.getElementById('signature-list');

    container.innerHTML = members.map(m => {
      const sig = covenant.signatures[m.id];
      const signed = !!sig;
      return `
        <div class="signature-card">
          <div class="avatar-lg" style="background:${m.color}">${m.name[0]}</div>
          <div class="name">${m.name}</div>
          <div class="status ${signed ? 'signed' : 'unsigned'}">
            ${signed ? '✓ 已签署 · ' + Utils.fmtDate(sig.signedAt) : '未签署'}
          </div>
          ${!signed && m.id === user.id
            ? `<button class="btn-primary btn-sm" id="btn-sign-self" style="margin-top:8px">签字画押</button>`
            : signed && m.id === user.id
            ? `<div style="font-size:12px;color:var(--text-muted);margin-top:8px">已签字画押 ✓</div>`
            : ''}
        </div>`;
    }).join('');

    const signBtn = document.getElementById('btn-sign-self');
    if (signBtn) {
      signBtn.addEventListener('click', () => this.showSignatureCanvas());
    }
  },

  showSignatureCanvas() {
    const modal = Utils.modal(`
      <div class="modal-header">
        <div class="modal-title">签字画押</div>
        <button class="modal-close" onclick="Utils.closeModal()">✕</button>
      </div>
      <p style="text-align:center;font-size:14px;color:var(--text-secondary);margin-bottom:16px">
        请在下方签名区写下你的名字
      </p>
      <div class="signature-canvas-wrap">
        <canvas id="sig-canvas" width="400" height="200" class="signature-canvas"></canvas>
      </div>
      <div class="modal-footer">
        <button class="btn-secondary" id="btn-clear-sig">清除</button>
        <button class="btn-primary" id="btn-submit-sig">确认签字</button>
      </div>
    `);

    const canvas = document.getElementById('sig-canvas');
    const ctx = canvas.getContext('2d');
    let drawing = false;
    let hasDrawn = false;
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#2D2D2D';

    const getPos = (e) => {
      const rect = canvas.getBoundingClientRect();
      const touch = e.touches ? e.touches[0] : e;
      return {
        x: (touch.clientX - rect.left) * (canvas.width / rect.width),
        y: (touch.clientY - rect.top) * (canvas.height / rect.height)
      };
    };

    const start = (e) => { e.preventDefault(); drawing = true; hasDrawn = true; const p = getPos(e); ctx.beginPath(); ctx.moveTo(p.x, p.y); };
    const move = (e) => {
      if (!drawing) return; e.preventDefault();
      const p = getPos(e);
      ctx.lineTo(p.x, p.y); ctx.stroke();
    };
    const end = (e) => { e.preventDefault(); drawing = false; };

    canvas.addEventListener('mousedown', start);
    canvas.addEventListener('mousemove', move);
    canvas.addEventListener('mouseup', end);
    canvas.addEventListener('mouseleave', end);
    canvas.addEventListener('touchstart', start);
    canvas.addEventListener('touchmove', move);
    canvas.addEventListener('touchend', end);

    document.getElementById('btn-clear-sig').addEventListener('click', () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      hasDrawn = false;
    });

    document.getElementById('btn-submit-sig').addEventListener('click', () => {
      if (!hasDrawn) return Toast.show('请先签名', 'error');
      const user = Auth.currentUser;
      DB.signCovenant(user.id);
      DB.updateUser(user.id, { covenantAgreed: true });
      Utils.closeModal();
      Toast.show('签字成功！', 'success');
      this.showSignCeremony();
    });
  },

  showSignCeremony() {
    const user = Auth.currentUser;
    const overlay = document.createElement('div');
    overlay.className = 'ceremony-overlay';
    overlay.innerHTML = `
      <div class="ceremony-content">
        <div class="ceremony-icon">📜✨</div>
        <div class="ceremony-title">签字画押完成</div>
        <div class="ceremony-subtitle">${user.name}，你已正式签署舍友公约</div>
        <div class="ceremony-blessing">
          一言为定，画押为证。<br>
          愿我们在这方天地里，<br>
          各守其分，互谅互让，<br>
          把日子过成彼此温暖的光。✨
        </div>
        <button class="ceremony-btn" id="btn-ceremony-close2">继续</button>
      </div>
    `;
    document.body.appendChild(overlay);
    Auth.spawnConfetti(overlay);

    document.getElementById('btn-ceremony-close2').addEventListener('click', () => {
      overlay.remove();
      this.render();
    });
  },

  showEditModal() {
    const covenant = DB.getCovenant();

    const modal = Utils.modal(`
      <div class="modal-header">
        <div class="modal-title">编辑舍友公约</div>
        <button class="modal-close" onclick="Utils.closeModal()">✕</button>
      </div>
      <p style="font-size:13px;color:var(--text-muted);margin-bottom:12px">
        修改公约后，所有舍友需要重新签署确认
      </p>
      <div class="form-group">
        <label>公约内容</label>
        <textarea id="covenant-text" rows="16" style="font-size:14px;line-height:1.8">${covenant.content}</textarea>
      </div>
      <div class="modal-footer">
        <button class="btn-secondary" onclick="Utils.closeModal()">取消</button>
        <button class="btn-primary" id="btn-save-covenant">保存并重置签署</button>
      </div>
    `);

    document.getElementById('btn-save-covenant').addEventListener('click', () => {
      const text = document.getElementById('covenant-text').value.trim();
      if (!text) return Toast.show('公约内容不能为空', 'error');
      DB.setCovenantContent(text);
      DB.updateUser(Auth.currentUser.id, { covenantAgreed: false });
      Utils.closeModal();
      Toast.show('公约已更新，请重新签署', 'success');
      this.render();
    });
  },
};
