/* ===== Cleaning Schedule Module ===== */
const Cleaning = {
  weekOffset: 0,

  render() {
    const tpl = document.getElementById('tpl-cleaning');
    document.getElementById('page-content').innerHTML = '';
    document.getElementById('page-content').appendChild(tpl.content.cloneNode(true));

    document.getElementById('btn-edit-schedule').addEventListener('click', () => this.showEditModal());
    document.getElementById('prev-week').addEventListener('click', () => { this.weekOffset--; this.renderSchedule(); });
    document.getElementById('next-week').addEventListener('click', () => { this.weekOffset++; this.renderSchedule(); });

    this.renderSchedule();
    this.renderTasks();
  },

  getWeekDates(offset = 0) {
    const now = new Date();
    const day = now.getDay() || 7; // Mon=1..Sun=7
    const monday = new Date(now);
    monday.setDate(now.getDate() - day + 1 + offset * 7);
    const dates = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date(monday);
      d.setDate(monday.getDate() + i);
      dates.push(d);
    }
    return dates;
  },

  getWeekKey(dates) {
    return Utils.fmtDateISO(dates[0]) + '_' + Utils.fmtDateISO(dates[6]);
  },

  renderSchedule() {
    const user = Auth.currentUser;
    const members = DB.getHouseholdMembers(user.id);
    const dates = this.getWeekDates(this.weekOffset);
    const weekKey = this.getWeekKey(dates);
    const cleaning = DB.getCleaningSchedule();

    // Week label
    const fmt = d => `${d.getMonth() + 1}月${d.getDate()}日`;
    document.getElementById('week-range').textContent = `${fmt(dates[0])} - ${fmt(dates[6])}`;

    // Auto-generate assignments if none exist
    let assignments = cleaning.assignments || [];
    if (assignments.length === 0 && members.length > 0) {
      assignments = this.autoAssign(members, dates);
      DB.setCleaningAssignments(assignments);
    }

    const dayNames = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const container = document.getElementById('cleaning-schedule');
    if (members.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">🧹</div>
          <div class="empty-state-text">暂无舍友，无法排班</div>
        </div>`;
      return;
    }

    container.innerHTML = dates.map((date, i) => {
      const assignment = assignments.find(a => a.date === Utils.fmtDateISO(date));
      const assigneeId = assignment ? assignment.userId : null;
      const assignee = assigneeId ? DB.getUser(assigneeId) : null;
      const isToday = date.getTime() === today.getTime();
      const isPast = date < today;

      const statusBadge = isToday
        ? '<span class="schedule-status badge-pending">今天</span>'
        : isPast ? '<span class="schedule-status badge-info">已完成</span>' : '';

      return `
        <div class="schedule-row">
          <div class="schedule-day">${dayNames[i]} (${date.getMonth() + 1}/${date.getDate()})</div>
          <div class="schedule-assignee">
            ${assignee
              ? `<div class="avatar-sm" style="background:${assignee.color}">${assignee.name[0]}</div> <span>${assignee.name}</span>`
              : '<span style="color:var(--text-muted)">未安排</span>'}
          </div>
          ${statusBadge}
        </div>`;
    }).join('');
  },

  autoAssign(members, dates) {
    const tasks = ['客厅', '厨房', '卫生间', '阳台'];
    const assignments = [];
    // Rotate: each day, assign a member based on day index
    dates.forEach((date, i) => {
      const memberId = members[i % members.length].id;
      assignments.push({ date: Utils.fmtDateISO(date), userId: memberId, task: tasks[i % tasks.length] });
    });
    return assignments;
  },

  renderTasks() {
    const user = Auth.currentUser;
    const cleaning = DB.getCleaningSchedule();
    let tasks = cleaning.tasks || [];

    // Default tasks
    if (tasks.length === 0) {
      const defaults = ['客厅地面清扫拖地', '厨房台面+灶台清洁', '卫生间马桶+地面清洁', '垃圾袋更换丢弃', '公共物品归位整理'];
      defaults.forEach(t => DB.addCleaningTask(t));
      tasks = DB.getCleaningTasks();
    }

    const dates = this.getWeekDates(this.weekOffset);
    const weekKey = this.getWeekKey(dates);

    const container = document.getElementById('cleaning-tasks');
    if (tasks.length === 0) {
      container.innerHTML = `<div class="empty-state"><div class="empty-state-text">暂无任务</div></div>`;
      return;
    }

    container.innerHTML = tasks.map(t => {
      const done = DB.isTaskDone(weekKey, t.id, user.id);
      return `
        <div class="task-item">
          <div class="task-checkbox ${done ? 'checked' : ''}" data-task-id="${t.id}">${done ? '✓' : ''}</div>
          <span class="task-text ${done ? 'done' : ''}">${t.name}</span>
        </div>`;
    }).join('');

    container.querySelectorAll('[data-task-id]').forEach(box => {
      box.addEventListener('click', () => {
        const taskId = box.dataset.taskId;
        const newState = DB.toggleTaskDone(weekKey, taskId, user.id);
        box.classList.toggle('checked', newState);
        box.textContent = newState ? '✓' : '';
        const text = box.nextElementSibling;
        text.classList.toggle('done', newState);
        if (newState) Toast.show('任务已完成 ✓', 'success');
      });
    });
  },

  showEditModal() {
    const cleaning = DB.getCleaningSchedule();
    const tasks = cleaning.tasks || [];
    const user = Auth.currentUser;
    const members = DB.getHouseholdMembers(user.id);

    const modal = Utils.modal(`
      <div class="modal-header">
        <div class="modal-title">编辑清洁任务</div>
        <button class="modal-close" onclick="Utils.closeModal()">✕</button>
      </div>
      <div class="form-group">
        <label>任务列表</label>
        <div id="task-editor" style="margin-bottom:12px">
          ${tasks.map(t => `
            <div class="task-item" data-edit-task="${t.id}" style="border:1px solid var(--border);border-radius:8px;margin-bottom:4px">
              <span class="task-text" style="flex:1">${t.name}</span>
              <button class="btn-text" style="color:var(--danger)" data-remove-task="${t.id}">删除</button>
            </div>
          `).join('')}
        </div>
        <div class="form-row">
          <input type="text" id="new-task-name" placeholder="新任务名称" style="flex:1">
          <button class="btn-primary btn-sm" id="btn-add-task">添加</button>
        </div>
      </div>
      <div class="form-group">
        <label>重新排班</label>
        <p style="font-size:13px;color:var(--text-muted);margin-bottom:8px">根据舍友日常作息重新生成本周排班表</p>
        <div class="form-row">
          <div class="form-group">
            <label>你的睡觉时间</label>
            <input type="time" id="routine-sleep" value="${user.routine?.sleepTime || '23:00'}">
          </div>
          <div class="form-group">
            <label>你的起床时间</label>
            <input type="time" id="routine-wake" value="${user.routine?.wakeTime || '08:00'}">
          </div>
        </div>
        <button class="btn-secondary btn-full" id="btn-regenerate">重新生成排班</button>
      </div>
      <div class="modal-footer">
        <button class="btn-primary btn-full" onclick="Utils.closeModal()">完成</button>
      </div>
    `);

    document.getElementById('btn-add-task').addEventListener('click', () => {
      const name = document.getElementById('new-task-name').value.trim();
      if (!name) return Toast.show('请输入任务名称', 'error');
      DB.addCleaningTask(name);
      Toast.show('任务已添加', 'success');
      Utils.closeModal();
      this.render();
    });

    document.querySelectorAll('[data-remove-task]').forEach(btn => {
      btn.addEventListener('click', () => {
        DB.removeCleaningTask(btn.dataset.removeTask);
        Toast.show('任务已删除', 'info');
        Utils.closeModal();
        this.render();
      });
    });

    document.getElementById('btn-regenerate').addEventListener('click', () => {
      const sleepTime = document.getElementById('routine-sleep').value;
      const wakeTime = document.getElementById('routine-wake').value;
      DB.updateUser(user.id, { routine: { sleepTime, wakeTime } });

      // Simple rotation logic: sort by wake time (earliest first gets earlier days)
      const allMembers = DB.getHouseholdMembers(user.id).map(m => ({
        ...m,
        routine: m.routine || { sleepTime: '23:00', wakeTime: '08:00' }
      }));
      allMembers.sort((a, b) => (a.routine.wakeTime || '08:00').localeCompare(b.routine.wakeTime || '08:00'));

      const dates = this.getWeekDates(0);
      const assignments = this.autoAssign(allMembers, dates);
      DB.setCleaningAssignments(assignments);
      Toast.show('排班已重新生成', 'success');
      Utils.closeModal();
      this.render();
    });
  },
};
