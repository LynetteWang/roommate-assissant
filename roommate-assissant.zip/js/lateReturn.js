/* ===== Late Return Module ===== */
const LateReturn = {
  currentTab: 'recent',

  render() {
    const tpl = document.getElementById('tpl-lateReturn');
    document.getElementById('page-content').innerHTML = '';
    document.getElementById('page-content').appendChild(tpl.content.cloneNode(true));

    document.getElementById('btn-new-late').addEventListener('click', () => this.showCreateModal());

    document.querySelectorAll('[data-late-tab]').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('[data-late-tab]').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        this.currentTab = tab.dataset.lateTab;
        this.renderList();
      });
    });

    this.renderBanner();
    this.renderList();
  },

  renderBanner() {
    const user = Auth.currentUser;
    const records = DB.getLateReturnsByHousehold(user.id);
    const now = new Date();
    const todayStr = now.toISOString().slice(0, 10);

    // Find late returns for today from others
    const todaysLate = records.filter(r => {
      const rUser = DB.getUser(r.userId);
      return rUser && rUser.id !== user.id && r.createdAt.slice(0, 10) === todayStr;
    });

    const banner = document.getElementById('late-banner');
    if (todaysLate.length > 0) {
      banner.classList.add('show');
      const names = todaysLate.map(r => {
        const u = DB.getUser(r.userId);
        return `${u.name}（约${r.expectedTime}）`;
      }).join('、');
      banner.innerHTML = `
        <h3>🌙 今晚有舍友晚归</h3>
        <p>${names}</p>
        <p style="margin-top:8px;font-size:13px;opacity:0.8">如果你的舍友晚归，请互相体谅～</p>
      `;
    }

    // Check if I have a late return today
    const myLate = records.find(r => r.userId === user.id && r.createdAt.slice(0, 10) === todayStr);
    if (myLate) {
      banner.classList.add('show');
      banner.innerHTML = `
        <h3>🌙 你已登记今晚晚归</h3>
        <p>预计到家时间：${myLate.expectedTime}</p>
        <p style="margin-top:8px;font-size:13px;opacity:0.9">🌙 请放轻脚步，不要打扰到你的舍友哦～</p>
      `;
    }
  },

  renderList() {
    const user = Auth.currentUser;
    const allRecords = DB.getLateReturnsByHousehold(user.id);

    let records = [];
    if (this.currentTab === 'recent') {
      records = allRecords.slice(0, 20);
    } else {
      records = allRecords.filter(r => r.userId === user.id);
    }

    const container = document.getElementById('late-list');
    if (records.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">🌙</div>
          <div class="empty-state-text">暂无晚归登记</div>
        </div>`;
      return;
    }

    container.innerHTML = records.map(r => {
      const u = DB.getUser(r.userId);
      const isMe = r.userId === user.id;
      const ackCount = Object.keys(r.acknowledged || {}).length;
      const members = DB.getHouseholdMembers(user.id);
      const otherCount = members.length - 1;
      const isAcknowledged = r.acknowledged && r.acknowledged[user.id];

      let statusBadge = '';
      if (isMe) {
        statusBadge = ackCount >= otherCount
          ? '<span class="badge badge-paid">已通知</span>'
          : `<span class="badge badge-pending">${ackCount}/${otherCount} 已知悉</span>`;
      } else {
        statusBadge = isAcknowledged
          ? '<span class="badge badge-paid">已知悉</span>'
          : '<span class="badge badge-info">待知悉</span>';
      }

      let actionBtn = '';
      if (!isMe && !isAcknowledged) {
        actionBtn = `<button class="btn-primary btn-sm" data-ack="${r.id}">我已知晓</button>`;
      }

      return `
        <div class="late-card">
          <div class="late-card-icon">🌙</div>
          <div class="late-card-info">
            <div class="late-card-person">${isMe ? '我' : u.name}</div>
            <div class="late-card-time">预计到家：${r.expectedTime}</div>
            <div class="late-card-reason">${r.reason || '未填写原因'}</div>
            <div style="font-size:12px;color:var(--text-muted);margin-top:4px">${Utils.fmtDate(r.createdAt)} 登记</div>
          </div>
          <div style="display:flex;flex-direction:column;align-items:flex-end;gap:8px">
            ${statusBadge}
            ${actionBtn}
          </div>
        </div>`;
    }).join('');

    container.querySelectorAll('[data-ack]').forEach(btn => {
      btn.addEventListener('click', () => {
        DB.acknowledgeLateReturn(btn.dataset.ack, user.id);
        Toast.show('已确认知悉', 'success');
        this.renderList();
      });
    });
  },

  showCreateModal() {
    const today = new Date().toISOString().slice(0, 10);

    const modal = Utils.modal(`
      <div class="modal-header">
        <div class="modal-title">晚归申请</div>
        <button class="modal-close" onclick="Utils.closeModal()">✕</button>
      </div>
      <div class="form-group">
        <label>预计到家时间</label>
        <input type="time" id="late-time" value="23:00">
      </div>
      <div class="form-group">
        <label>原因（选填）</label>
        <textarea id="late-reason" placeholder="如 加班、聚餐、朋友聚会..." rows="3"></textarea>
      </div>
      <div class="late-banner show" style="margin-bottom:16px">
        <h3>🌙 温馨提示</h3>
        <p>请放轻脚步，不要打扰到你的舍友哦～</p>
      </div>
      <div class="modal-footer">
        <button class="btn-secondary" onclick="Utils.closeModal()">取消</button>
        <button class="btn-primary" id="btn-submit-late">提交申请</button>
      </div>
    `);

    document.getElementById('btn-submit-late').addEventListener('click', () => {
      const expectedTime = document.getElementById('late-time').value;
      const reason = document.getElementById('late-reason').value.trim();
      if (!expectedTime) return Toast.show('请选择预计到家时间', 'error');

      const user = Auth.currentUser;
      DB.createLateReturn({ userId: user.id, expectedTime, reason });
      Utils.closeModal();
      Toast.show('晚归申请已提交，舍友会收到通知', 'success');
      this.render();
    });
  },
};
