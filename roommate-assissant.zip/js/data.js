/* ===== Data Layer (LocalStorage Backend Simulation) ===== */
const DB = {
  _get(key, def) {
    try {
      const raw = localStorage.getItem('rlms_' + key);
      return raw ? JSON.parse(raw) : def;
    } catch { return def; }
  },
  _set(key, val) {
    localStorage.setItem('rlms_' + key, JSON.stringify(val));
  },
  _id() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
  },

  // ---- Users ----
  getUsers() { return this._get('users', []); },
  getUser(id) { return this.getUsers().find(u => u.id === id); },
  findUserByAccount(acc) {
    const users = this.getUsers();
    return users.find(u => u.account === acc);
  },
  createUser({ name, account, password }) {
    const users = this.getUsers();
    if (users.find(u => u.account === account)) return null;
    const colors = ['#3D7068', '#E8845F', '#5B9BD5', '#8B5CF6', '#E8C547'];
    const user = {
      id: this._id(),
      name,
      account,
      password,
      doorNumber: '',
      covenantAgreed: false,
      covenantSignedAt: null,
      color: colors[users.length % colors.length],
      createdAt: new Date().toISOString(),
      routine: { sleepTime: '23:00', wakeTime: '08:00' }
    };
    users.push(user);
    this._set('users', users);
    return user;
  },
  updateUser(id, patch) {
    const users = this.getUsers();
    const idx = users.findIndex(u => u.id === id);
    if (idx === -1) return null;
    users[idx] = { ...users[idx], ...patch };
    this._set('users', users);
    return users[idx];
  },
  getRoommates(currentUserId) {
    const me = this.getUser(currentUserId);
    if (!me || !me.doorNumber) return [];
    return this.getUsers().filter(u => u.doorNumber === me.doorNumber && u.id !== currentUserId);
  },
  getHouseholdMembers(currentUserId) {
    const me = this.getUser(currentUserId);
    if (!me || !me.doorNumber) return [me];
    return this.getUsers().filter(u => u.doorNumber === me.doorNumber);
  },

  // ---- Session ----
  getSession() { return this._get('session', null); },
  setSession(userId) { this._set('session', { userId, ts: Date.now() }); },
  clearSession() { localStorage.removeItem('rlms_session'); },

  // ---- Bills ----
  getBills() { return this._get('bills', []); },
  getBill(id) { return this.getBills().find(b => b.id === id); },
  getBillsByHousehold(userId) {
    const members = this.getHouseholdMembers(userId);
    const ids = members.map(m => m.id);
    return this.getBills().filter(b => b.splits.some(s => ids.includes(s.userId)))
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  },
  createBill({ title, category, amount, splits, creatorId, note }) {
    const bills = this.getBills();
    const bill = {
      id: this._id(),
      title,
      category: category || '其他',
      amount: parseFloat(amount),
      splits: splits.map(s => ({ ...s, paid: false, paidAt: null })),
      creatorId,
      note: note || '',
      createdAt: new Date().toISOString(),
    };
    bills.push(bill);
    this._set('bills', bills);
    return bill;
  },
  markBillPaid(billId, userId) {
    const bills = this.getBills();
    const bill = bills.find(b => b.id === billId);
    if (!bill) return;
    const split = bill.splits.find(s => s.userId === userId);
    if (split) {
      split.paid = true;
      split.paidAt = new Date().toISOString();
      this._set('bills', bills);
    }
  },
  deleteBill(billId) {
    const bills = this.getBills().filter(b => b.id !== billId);
    this._set('bills', bills);
  },

  // ---- Cleaning ----
  getCleaningSchedule() { return this._get('cleaning', { tasks: [], assignments: [], rotationIndex: 0 }); },
  setCleaningSchedule(data) { this._set('cleaning', data); },
  getCleaningTasks() { return this.getCleaningSchedule().tasks; },
  getCleaningAssignments() { return this.getCleaningSchedule().assignments; },
  addCleaningTask(name) {
    const data = this.getCleaningSchedule();
    data.tasks.push({ id: this._id(), name, required: true });
    this.setCleaningSchedule(data);
  },
  removeCleaningTask(id) {
    const data = this.getCleaningSchedule();
    data.tasks = data.tasks.filter(t => t.id !== id);
    this.setCleaningSchedule(data);
  },
  setCleaningAssignments(assignments) {
    const data = this.getCleaningSchedule();
    data.assignments = assignments;
    this.setCleaningSchedule(data);
  },
  toggleTaskDone(weekKey, taskId, userId) {
    const data = this.getCleaningSchedule();
    if (!data.taskProgress) data.taskProgress = {};
    if (!data.taskProgress[weekKey]) data.taskProgress[weekKey] = {};
    if (!data.taskProgress[weekKey][taskId]) data.taskProgress[weekKey][taskId] = {};
    data.taskProgress[weekKey][taskId][userId] = !data.taskProgress[weekKey][taskId][userId];
    this.setCleaningSchedule(data);
    return data.taskProgress[weekKey][taskId][userId];
  },
  isTaskDone(weekKey, taskId, userId) {
    const data = this.getCleaningSchedule();
    return data.taskProgress?.[weekKey]?.[taskId]?.[userId] || false;
  },

  // ---- Covenant ----
  getCovenant() {
    return this._get('covenant', {
      content: this._defaultCovenant(),
      version: 1,
      signatures: {}
    });
  },
  setCovenantContent(content) {
    const cov = this.getCovenant();
    cov.content = content;
    cov.version = (cov.version || 1) + 1;
    cov.signatures = {};
    this._set('covenant', cov);
  },
  signCovenant(userId) {
    const cov = this.getCovenant();
    cov.signatures[userId] = { signedAt: new Date().toISOString() };
    this._set('covenant', cov);
  },
  _defaultCovenant() {
    return `第一章 日常作息
1. 工作日晚22:30后请降低音量，不外放音乐/视频
2. 使用公共区域后及时归位，厨房用完即清理
3. 洗衣机使用前请确认无人正在排队

第二章 财务管理
1. 公共支出（房租/水电/网费）按约定比例分摊，每月1日结算
2. 单笔超过50元的公共采购需提前在群内告知
3. 收到账单后请在3天内确认付款

第三章 清洁卫生
1. 按排班表完成公共区域清洁（客厅/厨房/卫生间）
2. 个人区域保持整洁，不占用公共通道
3. 垃圾分类后按时丢弃，不积压

第四章 访客管理
1. 留宿访客需提前告知所有舍友
2. 访客活动范围以客厅和自己的房间为主
3. 访客使用公共设施需遵守本公约

第五章 沟通与尊重
1. 有问题直接沟通，不在背后议论
2. 尊重彼此隐私，不擅自进入他人房间
3. 共同维护良好居住环境，有事多商量`;
  },

  // ---- Activities ----
  getActivities() { return this._get('activities', []); },
  getActivitiesByHousehold(userId) {
    const members = this.getHouseholdMembers(userId);
    const ids = members.map(m => m.id);
    return this.getActivities()
      .filter(a => ids.includes(a.creatorId) || a.participants.some(p => ids.includes(p.userId)))
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  },
  createActivity({ title, type, date, time, location, description, maxPeople, creatorId }) {
    const activities = this.getActivities();
    const activity = {
      id: this._id(),
      title,
      type: type || '聚餐',
      date,
      time: time || '',
      location: location || '',
      description: description || '',
      maxPeople: maxPeople || 0,
      creatorId,
      participants: [{ userId: creatorId, joinedAt: new Date().toISOString() }],
      status: 'open',
      createdAt: new Date().toISOString(),
    };
    activities.push(activity);
    this._set('activities', activities);
    return activity;
  },
  joinActivity(activityId, userId) {
    const activities = this.getActivities();
    const act = activities.find(a => a.id === activityId);
    if (!act) return false;
    if (act.participants.find(p => p.userId === userId)) return false;
    if (act.maxPeople > 0 && act.participants.length >= act.maxPeople) return false;
    act.participants.push({ userId, joinedAt: new Date().toISOString() });
    this._set('activities', activities);
    return true;
  },
  leaveActivity(activityId, userId) {
    const activities = this.getActivities();
    const act = activities.find(a => a.id === activityId);
    if (!act) return;
    act.participants = act.participants.filter(p => p.userId !== userId);
    this._set('activities', activities);
  },
  closeActivity(activityId) {
    const activities = this.getActivities();
    const act = activities.find(a => a.id === activityId);
    if (act) { act.status = 'closed'; this._set('activities', activities); }
  },

  // ---- Late Returns ----
  getLateReturns() { return this._get('lateReturns', []); },
  getLateReturnsByHousehold(userId) {
    const members = this.getHouseholdMembers(userId);
    const ids = members.map(m => m.id);
    return this.getLateReturns()
      .filter(l => ids.includes(l.userId))
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  },
  createLateReturn({ userId, expectedTime, reason }) {
    const records = this.getLateReturns();
    const record = {
      id: this._id(),
      userId,
      expectedTime,
      reason: reason || '',
      acknowledged: {},
      createdAt: new Date().toISOString(),
    };
    records.push(record);
    this._set('lateReturns', records);
    return record;
  },
  acknowledgeLateReturn(id, userId) {
    const records = this.getLateReturns();
    const r = records.find(x => x.id === id);
    if (r) { r.acknowledged[userId] = true; this._set('lateReturns', records); }
  },
};
