/* ===== Activities Module ===== */
const Activities = {
  currentTab: 'upcoming',

  render() {
    const tpl = document.getElementById('tpl-activities');
    document.getElementById('page-content').innerHTML = '';
    document.getElementById('page-content').appendChild(tpl.content.cloneNode(true));

    document.getElementById('btn-new-activity').addEventListener('click', () => this.showCreateModal());

    document.querySelectorAll('[data-act-tab]').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('[data-act-tab]').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        this.currentTab = tab.dataset.actTab;
        this.renderList();
      });
    });

    this.renderList();
  },

  renderList() {
    const user = Auth.currentUser;
    const allActivities = DB.getActivitiesByHousehold(user.id);
    const now = new Date().toISOString().slice(0, 10);

    let activities = [];
    if (this.currentTab === 'upcoming') {
      activities = allActivities.filter(a => a.status !== 'closed' && a.date >= now);
    } else if (this.currentTab === 'mine') {
      activities = allActivities.filter(a => a.creatorId === user.id);
    } else {
      activities = allActivities.filter(a => a.status === 'closed' || a.date < now);
    }

    const container = document.getElementById('activity-list');
    if (activities.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">🎉</div>
          <div class="empty-state-text">暂无活动</div>
          <div class="empty-state-hint">发起一个活动邀请舍友一起玩吧</div>
        </div>`;
      return;
    }

    container.innerHTML = activities.map(a => this.activityCardHTML(a, user)).join('');

    container.querySelectorAll('[data-join]').forEach(btn => {
      btn.addEventListener('click', () => {
        DB.joinActivity(btn.dataset.join, user.id);
        Toast.show('已加入活动 🎉', 'success');
        this.renderList();
      });
    });
    container.querySelectorAll('[data-leave]').forEach(btn => {
      btn.addEventListener('click', () => {
        DB.leaveActivity(btn.dataset.leave, user.id);
        Toast.show('已退出活动', 'info');
        this.renderList();
      });
    });
    container.querySelectorAll('[data-close-act]').forEach(btn => {
      btn.addEventListener('click', () => {
        DB.closeActivity(btn.dataset.closeAct);
        Toast.show('活动已结束', 'info');
        this.renderList();
      });
    });
  },

  activityCardHTML(act, user) {
    const creator = DB.getUser(act.creatorId);
    const isCreator = act.creatorId === user.id;
    const isJoined = act.participants.find(p => p.userId === user.id);
    const isFull = act.maxPeople > 0 && act.participants.length >= act.maxPeople;

    const participantsHTML = act.participants.map(p => {
      const u = DB.getUser(p.userId);
      return u ? `<div class="avatar-sm" style="background:${u.color || '#999'}">${u.name[0]}</div>` : '';
    }).join('');

    const typeIcons = { '聚餐': '🍽️', '运动': '🏃', '出游': '🚗', '看电影': '🎬', '购物': '🛒', '其他': '🎉' };
    const icon = typeIcons[act.type] || '🎉';

    let actionBtn = '';
    if (!isJoined && !isFull && act.status === 'open') {
      actionBtn = `<button class="btn-primary btn-sm" data-join="${act.id}">加入活动</button>`;
    } else if (isJoined && !isCreator) {
      actionBtn = `<button class="btn-secondary btn-sm" data-leave="${act.id}">退出</button>`;
    } else if (isCreator) {
      actionBtn = `<button class="btn-secondary btn-sm" data-close-act="${act.id}">结束活动</button>`;
    } else if (isFull) {
      actionBtn = `<span class="badge badge-pending">已满</span>`;
    }

    return `
      <div class="activity-card">
        <div class="activity-card-header">
          <div>
            <div class="activity-title">${icon} ${act.title}</div>
          </div>
          <span class="activity-type">${act.type}</span>
        </div>
        <div class="activity-meta">
          <span>📅 ${act.date} ${act.time}</span>
          ${act.location ? `<span>📍 ${act.location}</span>` : ''}
          <span>👤 ${creator ? creator.name : '未知'}</span>
        </div>
        ${act.description ? `<div class="activity-desc">${act.description}</div>` : ''}
        <div class="activity-participants">
          <div class="participant-avatars">${participantsHTML}</div>
          <span class="participant-count">${act.participants.length}人参与${act.maxPeople ? '/' + act.maxPeople : ''}</span>
        </div>
        <div class="activity-card-footer">${actionBtn}</div>
      </div>`;
  },

  showCreateModal() {
    const user = Auth.currentUser;
    const types = ['聚餐', '运动', '出游', '看电影', '购物', '其他'];
    const today = new Date().toISOString().slice(0, 10);

    const modal = Utils.modal(`
      <div class="modal-header">
        <div class="modal-title">发起活动</div>
        <button class="modal-close" onclick="Utils.closeModal()">✕</button>
      </div>
      <div class="form-group">
        <label>活动名称</label>
        <input type="text" id="act-title" placeholder="如 周末火锅探店" maxlength="30">
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>类型</label>
          <select id="act-type">
            ${types.map(t => `<option value="${t}">${t}</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>日期</label>
          <input type="date" id="act-date" value="${today}" min="${today}">
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>时间</label>
          <input type="time" id="act-time" value="18:00">
        </div>
        <div class="form-group">
          <label>人数上限（0=不限）</label>
          <input type="number" id="act-max" value="3" min="0" max="10">
        </div>
      </div>
      <div class="form-group">
        <label>地点</label>
        <input type="text" id="act-location" placeholder="如 朝阳区三里屯" maxlength="30">
      </div>
      <div class="form-group">
        <label>描述</label>
        <textarea id="act-desc" placeholder="说说你想去的地方、想做的事..." rows="3"></textarea>
      </div>
      <div class="modal-footer">
        <button class="btn-secondary" onclick="Utils.closeModal()">取消</button>
        <button class="btn-primary" id="btn-create-act">发起</button>
      </div>
    `);

    document.getElementById('btn-create-act').addEventListener('click', () => {
      const title = document.getElementById('act-title').value.trim();
      const type = document.getElementById('act-type').value;
      const date = document.getElementById('act-date').value;
      const time = document.getElementById('act-time').value;
      const location = document.getElementById('act-location').value.trim();
      const description = document.getElementById('act-desc').value.trim();
      const maxPeople = parseInt(document.getElementById('act-max').value) || 0;

      if (!title) return Toast.show('请输入活动名称', 'error');
      if (!date) return Toast.show('请选择日期', 'error');

      DB.createActivity({ title, type, date, time, location, description, maxPeople, creatorId: user.id });
      Utils.closeModal();
      Toast.show('活动已发起，通知舍友一起加入吧！', 'success');
      this.renderList();
    });
  },
};
