/* ===== Auth Module ===== */
const Auth = {
  get currentUser() {
    const session = DB.getSession();
    if (!session) return null;
    return DB.getUser(session.userId);
  },

  renderLogin() {
    const tpl = document.getElementById('tpl-login');
    document.getElementById('app').innerHTML = '';
    document.getElementById('app').appendChild(tpl.content.cloneNode(true));

    // Tab switching
    document.querySelectorAll('.auth-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        const isLogin = tab.dataset.tab === 'login';
        document.getElementById('login-form').classList.toggle('hidden', !isLogin);
        document.getElementById('register-form').classList.toggle('hidden', isLogin);
      });
    });

    document.getElementById('btn-login').addEventListener('click', () => this.handleLogin());
    document.getElementById('btn-register').addEventListener('click', () => this.handleRegister());

    // Enter key support
    ['login-account', 'login-password'].forEach(id => {
      document.getElementById(id).addEventListener('keydown', e => {
        if (e.key === 'Enter') this.handleLogin();
      });
    });
  },

  handleLogin() {
    const account = document.getElementById('login-account').value.trim();
    const password = document.getElementById('login-password').value.trim();
    if (!account || !password) return Toast.show('请填写账号和密码', 'error');

    const user = DB.findUserByAccount(account);
    if (!user) return Toast.show('账号不存在，请先注册', 'error');
    if (user.password !== password) return Toast.show('密码错误', 'error');

    DB.setSession(user.id);
    Toast.show(`欢迎回来，${user.name}！`, 'success');
    this.checkOnboarding(user);
  },

  handleRegister() {
    const name = document.getElementById('reg-name').value.trim();
    const account = document.getElementById('reg-account').value.trim();
    const password = document.getElementById('reg-password').value.trim();
    if (!name || !account || !password) return Toast.show('请填写所有字段', 'error');
    if (password.length < 4) return Toast.show('密码至少4位', 'error');

    const user = DB.createUser({ name, account, password });
    if (!user) return Toast.show('该账号已注册', 'error');

    DB.setSession(user.id);
    Toast.show('注册成功！', 'success');
    this.renderDoorNumber();
  },

  renderDoorNumber() {
    const tpl = document.getElementById('tpl-door');
    document.getElementById('app').innerHTML = '';
    document.getElementById('app').appendChild(tpl.content.cloneNode(true));

    document.getElementById('btn-confirm-door').addEventListener('click', () => this.handleDoorNumber());
    document.getElementById('btn-skip-door').addEventListener('click', () => {
      Toast.show('稍后可在个人设置中填写门牌号', 'info');
      App.navigate('dashboard');
    });
    document.getElementById('door-number').addEventListener('keydown', e => {
      if (e.key === 'Enter') this.handleDoorNumber();
    });
  },

  handleDoorNumber() {
    const door = document.getElementById('door-number').value.trim();
    if (!door) return Toast.show('请输入门牌号', 'error');

    const user = this.currentUser;
    DB.updateUser(user.id, { doorNumber: door });

    // Check if covenant needs agreement
    if (!user.covenantAgreed) {
      this.renderCovenantConfirm();
    } else {
      Toast.show('门牌号已确认', 'success');
      App.navigate('dashboard');
    }
  },

  renderCovenantConfirm() {
    const tpl = document.getElementById('tpl-covenant-confirm');
    document.getElementById('app').innerHTML = '';
    document.getElementById('app').appendChild(tpl.content.cloneNode(true));

    const covenant = DB.getCovenant();
    document.getElementById('covenant-preview').textContent = covenant.content;

    const checkbox = document.getElementById('agree-covenant');
    const btn = document.getElementById('btn-agree-covenant');
    checkbox.addEventListener('change', () => {
      btn.disabled = !checkbox.checked;
    });
    btn.addEventListener('click', () => this.handleCovenantAgree());
  },

  handleCovenantAgree() {
    const user = this.currentUser;
    DB.updateUser(user.id, { covenantAgreed: true });
    DB.signCovenant(user.id);

    // Show ceremony
    this.showCeremony(() => {
      App.navigate('dashboard');
    });
  },

  showCeremony(onClose) {
    const overlay = document.createElement('div');
    overlay.className = 'ceremony-overlay';
    overlay.innerHTML = `
      <div class="ceremony-content">
        <div class="ceremony-icon">🤝</div>
        <div class="ceremony-title">欢迎进入新生活</div>
        <div class="ceremony-subtitle">公约签署完成</div>
        <div class="ceremony-blessing">
          从今天起，我们就是一个屋檐下的伙伴。<br>
          互相尊重，彼此照顾，<br>
          让这里成为我们共同温暖的港湾。<br>
          愿合租的日子，充满欢笑与和谐。
        </div>
        <button class="ceremony-btn" id="btn-ceremony-close">开始使用</button>
      </div>
    `;
    document.body.appendChild(overlay);

    // Confetti effect
    this.spawnConfetti(overlay);

    document.getElementById('btn-ceremony-close').addEventListener('click', () => {
      overlay.remove();
      onClose && onClose();
    });
  },

  spawnConfetti(container) {
    const colors = ['#FFD700', '#FF6B6B', '#4ECDC4', '#95E1D3', '#FCBAD3', '#AA96DA'];
    for (let i = 0; i < 30; i++) {
      const c = document.createElement('div');
      c.className = 'confetti';
      c.style.background = colors[Math.floor(Math.random() * colors.length)];
      c.style.left = Math.random() * 100 + '%';
      c.style.top = '-10px';
      c.style.borderRadius = Math.random() > 0.5 ? '50%' : '0';
      c.style.animation = `confettiFall ${2 + Math.random() * 2}s ${Math.random() * 1}s ease-in forwards`;
      container.appendChild(c);
    }
  },

  checkOnboarding(user) {
    if (!user) { this.renderLogin(); return; }
    if (!user.doorNumber) { this.renderDoorNumber(); return; }
    if (!user.covenantAgreed) { this.renderCovenantConfirm(); return; }
    App.render();
  },

  logout() {
    DB.clearSession();
    Toast.show('已退出登录', 'info');
    this.renderLogin();
  },
};
