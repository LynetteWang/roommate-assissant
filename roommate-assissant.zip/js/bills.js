/* ===== Bills (AA) Module ===== */
const Bills = {
  currentTab: 'all',

  render() {
    const tpl = document.getElementById('tpl-bills');
    document.getElementById('page-content').innerHTML = '';
    document.getElementById('page-content').appendChild(tpl.content.cloneNode(true));

    document.getElementById('btn-new-bill').addEventListener('click', () => this.showCreateModal());

    document.querySelectorAll('[data-bill-tab]').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('[data-bill-tab]').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        this.currentTab = tab.dataset.billTab;
        this.renderList();
      });
    });

    this.renderList();
  },

  renderList() {
    const user = Auth.currentUser;
    const allBills = DB.getBillsByHousehold(user.id);
    let bills = [];
    if (this.currentTab === 'all') bills = allBills;
    else if (this.currentTab === 'pending') bills = allBills.filter(b => b.splits.some(s => s.userId === user.id && !s.paid));
    else if (this.currentTab === 'paid') bills = allBills.filter(b => b.splits.every(s => s.paid));
    else if (this.currentTab === 'created') bills = allBills.filter(b => b.creatorId === user.id);

    const container = document.getElementById('bill-list');
    if (bills.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">💰</div>
          <div class="empty-state-text">暂无账单</div>
          <div class="empty-state-hint">点击右上角创建新账单</div>
        </div>`;
      return;
    }

    container.innerHTML = bills.map(b => this.billCardHTML(b, user)).join('');

    // Bind pay buttons
    container.querySelectorAll('[data-pay]').forEach(btn => {
      btn.addEventListener('click', () => {
        const [billId, userId] = btn.dataset.pay.split(':');
        DB.markBillPaid(billId, userId);
        Toast.show('已标记为已付款 ✓', 'success');
        this.renderList();
      });
    });
    // Bind delete buttons
    container.querySelectorAll('[data-del-bill]').forEach(btn => {
      btn.addEventListener('click', () => {
        if (confirm('确定删除这条账单？')) {
          DB.deleteBill(btn.dataset.delBill);
          Toast.show('账单已删除', 'info');
          this.renderList();
        }
      });
    });
  },

  billCardHTML(bill, user) {
    const totalPaid = bill.splits.filter(s => s.paid).length;
    const allPaid = totalPaid === bill.splits.length;
    const mySplit = bill.splits.find(s => s.userId === user.id);
    const isCreator = bill.creatorId === user.id;
    const creator = DB.getUser(bill.creatorId);
    const dateStr = Utils.fmtDate(bill.createdAt);

    const splitsHTML = bill.splits.map(s => {
      const u = DB.getUser(s.userId);
      if (!u) return '';
      const isMe = s.userId === user.id;
      return `
        <div class="bill-split-chip ${s.paid ? 'paid' : ''}">
          <div class="avatar-sm" style="background:${u.color || '#999'}">${u.name[0]}</div>
          <span>${isMe ? '我' : u.name}</span>
          <span style="color:${s.paid ? '#6BBF59' : '#999'}">${s.paid ? '✓已付' : '¥' + s.amount.toFixed(2)}</span>
        </div>`;
    }).join('');

    const payBtn = mySplit && !mySplit.paid
      ? `<button class="btn-primary btn-sm" data-pay="${bill.id}:${user.id}">我已付款</button>` : '';
    const delBtn = isCreator && !allPaid
      ? `<button class="btn-secondary btn-sm" data-del-bill="${bill.id}">删除</button>` : '';

    return `
      <div class="bill-card">
        <div class="bill-card-header">
          <div>
            <div class="bill-title">${bill.title}</div>
            <span class="badge ${allPaid ? 'badge-paid' : 'badge-pending'}">${allPaid ? '已结清' : '待付'}</span>
          </div>
          <div class="bill-amount">¥${bill.amount.toFixed(2)}</div>
        </div>
        <div class="bill-meta">
          <span>📅 ${dateStr}</span>
          <span>👤 ${creator ? creator.name : '未知'}</span>
          <span>🏷️ ${bill.category}</span>
        </div>
        ${bill.note ? `<div class="bill-meta" style="margin-bottom:8px">📝 ${bill.note}</div>` : ''}
        <div class="bill-splits">${splitsHTML}</div>
        <div class="bill-card-footer">${delBtn}${payBtn}</div>
      </div>`;
  },

  showCreateModal() {
    const user = Auth.currentUser;
    const members = DB.getHouseholdMembers(user.id);

    if (members.length < 2) {
      Toast.show('当前只有你一个住户，无法分摊账单', 'info');
    }

    const categories = ['房租', '水电费', '网费', '清洁用品', '家电', '消耗品', '聚餐', '其他'];

    const modal = Utils.modal(`
      <div class="modal-header">
        <div class="modal-title">新建账单</div>
        <button class="modal-close" onclick="Utils.closeModal()">✕</button>
      </div>
      <div class="form-group">
        <label>账单名称</label>
        <input type="text" id="bill-title" placeholder="如 9月房租" maxlength="20">
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>分类</label>
          <select id="bill-category">
            ${categories.map(c => `<option value="${c}">${c}</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>总金额</label>
          <input type="number" id="bill-amount" placeholder="0.00" min="0" step="0.01">
        </div>
      </div>
      <div class="form-group">
        <label>备注（选填）</label>
        <textarea id="bill-note" placeholder="补充说明..." rows="2"></textarea>
      </div>
      <div class="form-group">
        <label>分摊方式</label>
        <div style="display:flex;gap:8px;margin-bottom:12px">
          <button class="btn-secondary btn-sm" id="split-equal" style="flex:1">平均分</button>
          <button class="btn-secondary btn-sm" id="split-custom" style="flex:1">自定义比例</button>
        </div>
        <div id="split-rows" style="margin-top:8px">
          ${members.map(m => `
            <div class="split-row" data-uid="${m.id}">
              <div class="split-user">
                <div class="avatar-sm" style="background:${m.color || '#999'}">${m.name[0]}</div>
                <span>${m.name}</span>
              </div>
              <input type="number" class="split-ratio" value="1" min="0" step="1" style="width:60px;padding:6px">
              <div class="split-amount">¥0.00</div>
            </div>
          `).join('')}
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn-secondary" onclick="Utils.closeModal()">取消</button>
        <button class="btn-primary" id="btn-create-bill">创建并推送</button>
      </div>
    `);

    // Default: equal split
    let splitMode = 'equal';

    const updateAmounts = () => {
      const amount = parseFloat(document.getElementById('bill-amount').value) || 0;
      const rows = document.querySelectorAll('.split-row');
      const ratios = Array.from(rows).map(r => parseFloat(r.querySelector('.split-ratio').value) || 0);
      const totalRatio = ratios.reduce((a, b) => a + b, 0);
      rows.forEach((row, i) => {
        const amt = totalRatio > 0 ? (amount * ratios[i] / totalRatio) : 0;
        row.querySelector('.split-amount').textContent = '¥' + amt.toFixed(2);
      });
    };

    document.getElementById('bill-amount').addEventListener('input', updateAmounts);
    document.querySelectorAll('.split-ratio').forEach(r => r.addEventListener('input', updateAmounts));

    document.getElementById('split-equal').addEventListener('click', () => {
      splitMode = 'equal';
      document.querySelectorAll('.split-ratio').forEach(r => r.value = 1);
      updateAmounts();
      document.getElementById('split-equal').style.background = 'var(--primary-light)';
      document.getElementById('split-equal').style.color = 'var(--primary)';
      document.getElementById('split-custom').style.background = '';
      document.getElementById('split-custom').style.color = '';
    });
    document.getElementById('split-custom').addEventListener('click', () => {
      splitMode = 'custom';
      document.getElementById('split-custom').style.background = 'var(--primary-light)';
      document.getElementById('split-custom').style.color = 'var(--primary)';
      document.getElementById('split-equal').style.background = '';
      document.getElementById('split-equal').style.color = '';
    });
    document.getElementById('split-equal').click();

    document.getElementById('btn-create-bill').addEventListener('click', () => {
      const title = document.getElementById('bill-title').value.trim();
      const category = document.getElementById('bill-category').value;
      const amount = parseFloat(document.getElementById('bill-amount').value);
      const note = document.getElementById('bill-note').value.trim();
      if (!title) return Toast.show('请输入账单名称', 'error');
      if (!amount || amount <= 0) return Toast.show('请输入有效金额', 'error');

      const rows = document.querySelectorAll('.split-row');
      const ratios = Array.from(rows).map(r => parseFloat(r.querySelector('.split-ratio').value) || 0);
      const totalRatio = ratios.reduce((a, b) => a + b, 0);
      if (totalRatio <= 0) return Toast.show('分摊比例总和需大于0', 'error');

      const splits = Array.from(rows).map((row, i) => ({
        userId: row.dataset.uid,
        ratio: ratios[i],
        amount: parseFloat((amount * ratios[i] / totalRatio).toFixed(2)),
      }));

      DB.createBill({ title, category, amount, splits, creatorId: user.id, note });
      Utils.closeModal();
      Toast.show('账单已创建并推送给舍友', 'success');
      this.renderList();
    });
  },
};
