/* ===== Shared Utilities ===== */
const Utils = {
  fmtDate(iso) {
    const d = new Date(iso);
    return `${d.getMonth() + 1}月${d.getDate()}日 ${d.getHours()}:${String(d.getMinutes()).padStart(2, '0')}`;
  },
  fmtDateISO(d) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  },
  modal(html) {
    const root = document.getElementById('modal-root');
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `<div class="modal">${html}</div>`;
    root.appendChild(overlay);
    overlay.addEventListener('click', e => {
      if (e.target === overlay) overlay.remove();
    });
    return overlay;
  },
  closeModal() {
    const root = document.getElementById('modal-root');
    root.innerHTML = '';
  },
};

const Toast = {
  show(msg, type = 'info', duration = 2500) {
    const root = document.getElementById('toast-root');
    const t = document.createElement('div');
    t.className = `toast ${type}`;
    t.textContent = msg;
    root.appendChild(t);
    setTimeout(() => {
      t.style.opacity = '0';
      t.style.transition = 'opacity 0.3s';
      setTimeout(() => t.remove(), 300);
    }, duration);
  },
};

/* ===== Main App ===== */
const App = {
  routes: {
    dashboard: () => Dashboard.render(),
    bills: () => Bills.render(),
    cleaning: () => Cleaning.render(),
    covenant: () => Covenant.render(),
    activities: () => Activities.render(),
    lateReturn: () => LateReturn.render(),
  },

  init() {
    window.addEventListener('hashchange', () => this.render());

    const user = Auth.currentUser;
    if (!user) {
      Auth.renderLogin();
      return;
    }
    if (!user.doorNumber) {
      Auth.renderDoorNumber();
      return;
    }
    if (!user.covenantAgreed) {
      Auth.renderCovenantConfirm();
      return;
    }
    this.render();
  },

  navigate(route) {
    window.location.hash = '#/' + route;
  },

  getRoute() {
    const hash = window.location.hash.replace('#/', '') || 'dashboard';
    return this.routes[hash] ? hash : 'dashboard';
  },

  render() {
    const user = Auth.currentUser;
    if (!user) {
      Auth.renderLogin();
      return;
    }

    // Check onboarding
    if (!user.doorNumber) { Auth.renderDoorNumber(); return; }
    if (!user.covenantAgreed) { Auth.renderCovenantConfirm(); return; }

    // Render main layout
    const tpl = document.getElementById('tpl-main');
    document.getElementById('app').innerHTML = '';
    document.getElementById('app').appendChild(tpl.content.cloneNode(true));

    // Update sidebar user info
    this.updateSidebar();

    // Highlight active nav
    const route = this.getRoute();
    document.querySelectorAll('.nav-item').forEach(item => {
      item.classList.toggle('active', item.dataset.route === route);
    });

    // Logout
    document.getElementById('btn-logout').addEventListener('click', () => Auth.logout());

    // Render current page
    this.routes[route]();
  },

  updateSidebar() {
    const user = Auth.currentUser;
    const el = document.getElementById('sidebar-user');
    el.innerHTML = `
      <div class="user-avatar" style="background:${user.color}">${user.name[0]}</div>
      <div class="user-info-text">
        <span class="name">${user.name}</span>
        <span class="door">门牌号 ${user.doorNumber}</span>
      </div>
    `;
  },
};

/* ===== Dashboard Module ===== */
const Dashboard = {
  render() {
    const tpl = document.getElementById('tpl-dashboard');
    document.getElementById('page-content').innerHTML = '';
    document.getElementById('page-content').appendChild(tpl.content.cloneNode(true));

    const user = Auth.currentUser;
    const hour = new Date().getHours();
    let greeting = '你好';
    if (hour < 6) greeting = '夜深了';
    else if (hour < 11) greeting = '早上好';
    else if (hour < 14) greeting = '中午好';
    else if (hour < 18) greeting = '下午好';
    else greeting = '晚上好';

    document.getElementById('dash-greeting').textContent = `${greeting}，${user.name}`;
    const now = new Date();
    const weekdays = ['日', '一', '二', '三', '四', '五', '六'];
    document.getElementById('dash-date').textContent =
      `${now.getFullYear()}年${now.getMonth() + 1}月${now.getDate()}日 周${weekdays[now.getDay()]}`;

    this.renderStats(user);
    this.renderRoommates(user);
    this.renderTodos(user);

    // Card click navigation
    document.getElementById('dash-bills').addEventListener('click', () => App.navigate('bills'));
    document.getElementById('dash-cleaning').addEventListener('click', () => App.navigate('cleaning'));
    document.getElementById('dash-activities').addEventListener('click', () => App.navigate('activities'));
    document.getElementById('dash-late').addEventListener('click', () => App.navigate('lateReturn'));
  },

  renderStats(user) {
    // Pending bills
    const bills = DB.getBillsByHousehold(user.id);
    const pending = bills.filter(b => b.splits.some(s => s.userId === user.id && !s.paid));
    document.getElementById('dash-bills-count').textContent = `${pending.length} 笔`;

    // Cleaning
    const cleaning = DB.getCleaningSchedule();
    const assignments = cleaning.assignments || [];
    const todayISO = Utils.fmtDateISO(new Date());
    const todayAssign = assignments.find(a => a.date === todayISO);
    if (todayAssign) {
      const assignee = DB.getUser(todayAssign.userId);
      const isMe = todayAssign.userId === user.id;
      document.getElementById('dash-cleaning-info').textContent =
        isMe ? '今天轮到你' : `${assignee.name}`;
    } else {
      document.getElementById('dash-cleaning-info').textContent = '未安排';
    }

    // Activities
    const todayStr = new Date().toISOString().slice(0, 10);
    const activities = DB.getActivitiesByHousehold(user.id);
    const upcoming = activities.filter(a => a.status !== 'closed' && a.date >= todayStr);
    document.getElementById('dash-activities-count').textContent = `${upcoming.length} 个`;

    // Late returns
    const lateReturns = DB.getLateReturnsByHousehold(user.id);
    const todayLate = lateReturns.filter(r => r.createdAt.slice(0, 10) === todayStr);
    document.getElementById('dash-late-count').textContent = `${todayLate.length} 条`;
  },

  renderRoommates(user) {
    const members = DB.getHouseholdMembers(user.id);
    const todayStr = new Date().toISOString().slice(0, 10);
    const lateReturns = DB.getLateReturnsByHousehold(user.id);
    const todayLate = lateReturns.filter(r => r.createdAt.slice(0, 10) === todayStr);

    const el = document.getElementById('dash-roommates');
    el.innerHTML = members.map(m => {
      const lateToday = todayLate.find(r => r.userId === m.id);
      const isMe = m.id === user.id;
      let status = '';
      let statusColor = '#6BBF59';
      if (lateToday) {
        status = `🌙 晚归 ${lateToday.expectedTime}`;
        statusColor = '#E8C547';
      } else {
        const hour = new Date().getHours();
        if (hour >= 22 || hour < 6) status = '🌙 可能已休息';
        else if (hour >= 9 && hour < 18) status = '☀️ 外出中';
        else status = '🏠 在家';
      }
      return `
        <div class="roommate-chip">
          <div class="roommate-chip-avatar" style="background:${m.color}">${m.name[0]}</div>
          <div class="roommate-chip-name">${isMe ? '我' : m.name}</div>
          <div class="roommate-chip-door">${m.doorNumber || '未设置'}</div>
          <div class="roommate-chip-status" style="background:${statusColor}20;color:${statusColor}">${status}</div>
        </div>`;
    }).join('');
  },

  renderTodos(user) {
    const todos = [];
    const todayStr = new Date().toISOString().slice(0, 10);

    // Pending bills
    const bills = DB.getBillsByHousehold(user.id);
    const pendingBills = bills.filter(b => b.splits.some(s => s.userId === user.id && !s.paid));
    if (pendingBills.length > 0) {
      const total = pendingBills.reduce((sum, b) => {
        const s = b.splits.find(sp => sp.userId === user.id);
        return sum + (s ? s.amount : 0);
      }, 0);
      todos.push({ icon: '#E8C547', text: `待付账单 ${pendingBills.length} 笔，共 ¥${total.toFixed(2)}`, route: 'bills' });
    }

    // Today's cleaning
    const cleaning = DB.getCleaningSchedule();
    const assignments = cleaning.assignments || [];
    const todayAssign = assignments.find(a => a.date === todayStr);
    if (todayAssign && todayAssign.userId === user.id) {
      todos.push({ icon: '#3D7068', text: '今天轮到你做公共区域清洁', route: 'cleaning' });
    }

    // Unread late returns
    const lateReturns = DB.getLateReturnsByHousehold(user.id);
    const unread = lateReturns.filter(r => r.userId !== user.id && !(r.acknowledged && r.acknowledged[user.id]) && r.createdAt.slice(0, 10) === todayStr);
    if (unread.length > 0) {
      todos.push({ icon: '#5B9BD5', text: `${unread.length} 位舍友今晚晚归`, route: 'lateReturn' });
    }

    // Upcoming activities
    const activities = DB.getActivitiesByHousehold(user.id);
    const upcomingActs = activities.filter(a => a.status !== 'closed' && a.date >= todayStr && !a.participants.find(p => p.userId === user.id));
    if (upcomingActs.length > 0) {
      todos.push({ icon: '#E8845F', text: `${upcomingActs.length} 个活动等你加入`, route: 'activities' });
    }

    // Unsigned covenant
    const covenant = DB.getCovenant();
    const members = DB.getHouseholdMembers(user.id);
    const unsigned = members.filter(m => !covenant.signatures[m.id]);
    if (unsigned.length > 0) {
      todos.push({ icon: '#E85D5D', text: `${unsigned.length} 位舍友尚未签署公约`, route: 'covenant' });
    }

    const el = document.getElementById('dash-todos');
    if (todos.length === 0) {
      el.innerHTML = `<div class="empty-state"><div class="empty-state-text">🎉 暂无待办，享受生活吧</div></div>`;
      return;
    }
    el.innerHTML = todos.map(t => `
      <div class="todo-item" data-todo-route="${t.route}" style="cursor:pointer">
        <div class="todo-dot" style="background:${t.icon}"></div>
        <span class="todo-text">${t.text}</span>
        <span class="todo-action">查看 →</span>
      </div>
    `).join('');
    el.querySelectorAll('[data-todo-route]').forEach(item => {
      item.addEventListener('click', () => App.navigate(item.dataset.todoRoute));
    });
  },
};

/* ===== Bootstrap ===== */
document.addEventListener('DOMContentLoaded', () => {
  App.init();
});
